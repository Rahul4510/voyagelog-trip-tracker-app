import { motion } from "framer-motion";
import { MapPin, CreditCard, Camera, BarChart3, Cloud, Route } from "lucide-react";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const features = [
  {
    icon: MapPin,
    title: "GPS Travel Tracking",
    description: "Automatically track travel routes using GPS. Every meter logged, every trip stored.",
    accent: "primary" as const,
  },
  {
    icon: Route,
    title: "Interactive Maps",
    description: "Visualize routes on high-fidelity maps with live markers and trip history replay.",
    accent: "primary" as const,
  },
  {
    icon: CreditCard,
    title: "Expense Tracking",
    description: "Log transportation, food, accommodation, and activities. View detailed trip summaries.",
    accent: "accent" as const,
  },
  {
    icon: Camera,
    title: "Photo & Memory Storage",
    description: "Upload trip photos with location tags. Your memories, geo-referenced and secured.",
    accent: "primary" as const,
  },
  {
    icon: BarChart3,
    title: "Travel Analytics",
    description: "Total distance, total expenses, most visited locations—all in one dashboard.",
    accent: "accent" as const,
  },
  {
    icon: Cloud,
    title: "Secure Cloud Backup",
    description: "AES-256 encrypted storage. Your data is accessible from anywhere, owned by you alone.",
    accent: "primary" as const,
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="section-padding bg-muted/50">
      <div className="container mx-auto">
        <motion.div {...fadeInUp} className="text-center mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
            Core Capabilities
          </span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4">
            Everything you need to travel smarter
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Six integrated modules designed for digital nomads, corporate travelers, and privacy-conscious explorers.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              {...fadeInUp}
              transition={{ ...fadeInUp.transition, delay: index * 0.08 }}
              className="group bg-card rounded-3xl p-8 shadow-card hover:shadow-elevated transition-all duration-300 hover:-translate-y-1"
            >
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-5 ${
                  feature.accent === "accent"
                    ? "bg-accent/10 text-accent"
                    : "bg-primary/10 text-primary"
                }`}
              >
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
