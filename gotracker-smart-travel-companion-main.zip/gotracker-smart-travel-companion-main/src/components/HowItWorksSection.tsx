import { motion } from "framer-motion";
import { Download, MapPin, BarChart3, Lock } from "lucide-react";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const steps = [
  {
    number: "01",
    icon: Download,
    title: "Sign Up & Set Up",
    description: "Create your encrypted account in under 60 seconds. Your vault is ready.",
  },
  {
    number: "02",
    icon: MapPin,
    title: "Enable Trip Mode",
    description: "Activate GPS tracking only when you travel. Your privacy is always respected.",
  },
  {
    number: "03",
    icon: BarChart3,
    title: "Track & Analyze",
    description: "Routes, expenses, photos—everything logged and visualized automatically.",
  },
  {
    number: "04",
    icon: Lock,
    title: "Settle & Secure",
    description: "Split costs via UPI, backup your data, and access it from anywhere.",
  },
];

const HowItWorksSection = () => {
  return (
    <section className="section-padding bg-muted/50">
      <div className="container mx-auto">
        <motion.div {...fadeInUp} className="text-center mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
            Workflow
          </span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
            How GoTracker works
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              {...fadeInUp}
              transition={{ ...fadeInUp.transition, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-card shadow-card flex items-center justify-center mx-auto mb-5">
                <step.icon className="w-7 h-7 text-primary" />
              </div>
              <span className="text-xs font-mono text-primary/50 uppercase tracking-widest">
                Step {step.number}
              </span>
              <h3 className="text-lg font-semibold text-foreground mt-2 mb-2">
                {step.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
