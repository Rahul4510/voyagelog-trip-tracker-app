import { motion } from "framer-motion";
import { Shield, Lock, Eye, Server, Key, Fingerprint } from "lucide-react";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const statusItems = [
  { label: "SSL Certificate", status: "Active", icon: Lock, ok: true },
  { label: "Database Encryption", status: "AES-256", icon: Server, ok: true },
  { label: "Authentication", status: "JWT + MFA", icon: Key, ok: true },
  { label: "Password Hashing", status: "bcrypt", icon: Fingerprint, ok: true },
  { label: "XSS Protection", status: "Enabled", icon: Shield, ok: true },
  { label: "Location Privacy", status: "User-Only", icon: Eye, ok: true },
];

const SecuritySection = () => {
  return (
    <section id="security" className="section-padding">
      <div className="container mx-auto">
        <motion.div {...fadeInUp} className="text-center mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
            Security Protocol
          </span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4">
            Bank-grade security for your travel data
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Your location, expenses, and memories are protected by the same
            standards used by financial institutions.
          </p>
        </motion.div>

        {/* System health dashboard */}
        <motion.div
          {...fadeInUp}
          transition={{ ...fadeInUp.transition, delay: 0.1 }}
          className="max-w-3xl mx-auto"
        >
          <div className="rounded-3xl bg-card shadow-elevated overflow-hidden">
            <div className="px-8 py-5 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-accent" />
                <span className="text-sm font-semibold text-foreground">
                  System Health
                </span>
              </div>
              <span className="text-xs font-mono text-accent uppercase tracking-widest">
                ● All Systems Operational
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {statusItems.map((item, index) => (
                <div
                  key={item.label}
                  className={`px-8 py-6 flex items-start gap-4 ${
                    index < statusItems.length - (statusItems.length % 3 || 3)
                      ? "border-b border-border"
                      : ""
                  } ${index % 3 !== 2 ? "lg:border-r" : ""} ${
                    index % 2 !== 1 ? "sm:border-r lg:border-r-0" : "sm:border-r-0"
                  } lg:${index % 3 !== 2 ? "border-r" : "border-r-0"}`}
                  style={{
                    borderRight:
                      index % 3 !== 2
                        ? "1px solid hsl(var(--border))"
                        : "none",
                  }}
                >
                  <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                      {item.label}
                    </p>
                    <p className="text-sm font-semibold text-foreground mt-1">
                      {item.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Protection list */}
        <motion.div
          {...fadeInUp}
          transition={{ ...fadeInUp.transition, delay: 0.2 }}
          className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto"
        >
          {[
            "SQL Injection",
            "XSS Attacks",
            "CSRF Protection",
            "Rate Limiting",
          ].map((item) => (
            <div
              key={item}
              className="text-center px-4 py-4 rounded-2xl bg-muted"
            >
              <Shield className="w-4 h-4 text-primary mx-auto mb-2" />
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                {item}
              </p>
              <p className="text-xs font-semibold text-accent mt-1">Protected</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default SecuritySection;
