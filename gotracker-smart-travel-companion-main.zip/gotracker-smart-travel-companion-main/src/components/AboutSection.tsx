import { motion } from "framer-motion";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-muted/50">
      <div className="container mx-auto max-w-3xl text-center">
        <motion.div {...fadeInUp}>
          <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
            About
          </span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-6">
            Built for travelers who demand precision
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            GoTracker was born from frustration with travel apps that prioritize
            social features over utility. We believe your travel data deserves
            the same level of protection and precision as your financial data.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Every feature is designed with security-first principles: encrypted
            storage, permission-based GPS, and zero third-party data sharing.
            Whether you're a digital nomad, corporate traveler, or weekend
            explorer—GoTracker gives you a private, intelligent travel vault.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
