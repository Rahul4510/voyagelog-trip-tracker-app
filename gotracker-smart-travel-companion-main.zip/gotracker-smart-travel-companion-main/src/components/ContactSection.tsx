import { motion } from "framer-motion";
import { Mail, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const ContactSection = () => {
  return (
    <section id="contact" className="section-padding">
      <div className="container mx-auto max-w-2xl">
        <motion.div {...fadeInUp} className="rounded-3xl bg-card shadow-elevated p-8 md:p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Mail className="w-7 h-7 text-primary" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground mb-3">
            Ready to start tracking?
          </h2>
          <p className="text-muted-foreground mb-8">
            Join thousands of travelers who document their journeys with
            precision and security.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" className="gap-2 px-8 h-12">
              Start Tracking <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="lg" className="gap-2 px-8 h-12">
              Learn More
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-6 font-mono">
            contact@gotracker.app
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactSection;
