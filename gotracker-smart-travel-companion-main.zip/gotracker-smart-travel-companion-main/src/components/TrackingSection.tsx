import { motion } from "framer-motion";
import { Navigation, MapPin, Clock, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const tripData = [
  { label: "Distance", value: "342.7 km", icon: Gauge },
  { label: "Duration", value: "4h 23m", icon: Clock },
  { label: "Waypoints", value: "12", icon: MapPin },
];

const TrackingSection = () => {
  return (
    <section id="tracking" className="section-padding">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div {...fadeInUp}>
            <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
              GPS + Maps
            </span>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-6">
              Log every meter.
              <br />
              <span className="text-primary">Visualize every route.</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 max-w-lg">
              High-precision GPS tracking with interactive map visualization.
              View live routes, replay trip history, and explore your travel
              footprint across the globe.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button className="gap-2">
                <Navigation className="w-4 h-4" /> View Map
              </Button>
              <Button variant="outline">Try Demo</Button>
            </div>
          </motion.div>

          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.15 }}
          >
            {/* Map simulation card */}
            <div className="rounded-3xl overflow-hidden shadow-elevated bg-foreground relative">
              <div className="aspect-[4/3] bg-gradient-to-br from-[hsl(220,30%,12%)] to-[hsl(220,20%,8%)] relative p-6 flex flex-col">
                {/* Simulated map grid */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px]" />

                {/* Route line */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 300">
                  <motion.path
                    d="M 60 240 Q 100 180 140 160 T 220 120 T 300 80 T 360 60"
                    fill="none"
                    stroke="hsl(217, 91%, 60%)"
                    strokeWidth="3"
                    strokeLinecap="round"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 2, ease: "easeInOut" }}
                  />
                  <circle cx="60" cy="240" r="6" fill="hsl(142, 71%, 45%)" />
                  <circle cx="360" cy="60" r="6" fill="hsl(217, 91%, 60%)" />
                  <motion.circle
                    cx="360"
                    cy="60"
                    r="12"
                    fill="none"
                    stroke="hsl(217, 91%, 60%)"
                    strokeWidth="2"
                    opacity="0.4"
                    initial={{ r: 6 }}
                    animate={{ r: 18, opacity: 0 }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                </svg>

                {/* Trip header */}
                <div className="relative z-10 flex justify-between items-start">
                  <div>
                    <p className="text-xs font-mono uppercase tracking-widest text-primary/70">
                      Active Trip
                    </p>
                    <p className="text-sm font-semibold text-primary-foreground mt-1">
                      Delhi → Jaipur
                    </p>
                  </div>
                  <span className="px-2 py-1 rounded-full bg-accent/20 text-accent text-xs font-mono">
                    ● Recording
                  </span>
                </div>

                {/* Bottom stats */}
                <div className="relative z-10 mt-auto flex gap-6">
                  {tripData.map((stat) => (
                    <div key={stat.label}>
                      <p className="text-xs font-mono uppercase tracking-widest text-primary-foreground/40">
                        {stat.label}
                      </p>
                      <p className="text-lg font-mono font-semibold text-primary-foreground tabular-nums mt-0.5">
                        {stat.value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TrackingSection;
