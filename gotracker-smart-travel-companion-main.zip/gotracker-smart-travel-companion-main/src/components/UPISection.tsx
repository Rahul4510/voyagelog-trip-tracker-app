import { motion } from "framer-motion";
import { Smartphone, QrCode, ArrowRight, IndianRupee } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const useCases = [
  "Group trip expense settlement",
  "Travel organizer payments",
  "Premium feature purchase",
];

const UPISection = () => {
  return (
    <section id="payments" className="section-padding bg-muted/50">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Payment card */}
          <motion.div
            {...fadeInUp}
            className="order-2 lg:order-1 flex justify-center"
          >
            <div className="w-full max-w-sm rounded-3xl bg-card shadow-elevated p-8">
              <div className="text-center mb-6">
                <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <IndianRupee className="w-7 h-7 text-accent" />
                </div>
                <p className="text-sm font-mono uppercase tracking-widest text-muted-foreground">
                  Settlement Amount
                </p>
                <p className="text-4xl font-bold text-foreground mt-2 tabular-nums font-mono">
                  ₹500.00
                </p>
              </div>

              {/* QR code placeholder */}
              <div className="rounded-2xl bg-muted p-6 mb-6">
                <div className="aspect-square max-w-[180px] mx-auto bg-foreground rounded-xl flex items-center justify-center">
                  <QrCode className="w-24 h-24 text-primary-foreground" />
                </div>
                <p className="text-[10px] font-mono text-muted-foreground text-center mt-3 break-all">
                  upi://pay?pa=gotracker@upi&pn=GoTracker&am=500&cu=INR
                </p>
              </div>

              <div className="flex gap-3">
                <Button className="flex-1 gap-2 h-12">
                  <Smartphone className="w-4 h-4" /> Google Pay
                </Button>
                <Button variant="outline" className="flex-1 gap-2 h-12">
                  <Smartphone className="w-4 h-4" /> PhonePe
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Text content */}
          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.1 }}
            className="order-1 lg:order-2"
          >
            <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
              UPI Payments
            </span>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-6">
              Settle instantly.
              <br />
              <span className="text-accent">Zero friction payments.</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 max-w-lg">
              Split trip expenses, pay organizers, or unlock premium features—all
              through secure UPI links and QR codes. Supports Google Pay and
              PhonePe.
            </p>

            <ul className="space-y-3 mb-8">
              {useCases.map((item) => (
                <li key={item} className="flex items-center gap-3 text-sm text-foreground">
                  <span className="w-5 h-5 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <ArrowRight className="w-3 h-3 text-accent" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>

            <Button variant="outline" className="gap-2">
              Pay with UPI <ArrowRight className="w-4 h-4" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default UPISection;
