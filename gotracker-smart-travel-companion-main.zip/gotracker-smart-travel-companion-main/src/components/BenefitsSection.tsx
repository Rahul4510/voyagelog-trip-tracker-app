import { motion } from "framer-motion";
import { Zap, Globe, Users, ShieldCheck } from "lucide-react";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.4, ease: "easeOut" as const },
};

const benefits = [
  {
    icon: Zap,
    title: "Blazing Fast",
    description: "Optimized for low-bandwidth environments. Works offline and syncs when you reconnect.",
  },
  {
    icon: Globe,
    title: "Works Everywhere",
    description: "Track trips across 195 countries. Multi-currency expense support built in.",
  },
  {
    icon: Users,
    title: "Built for Teams",
    description: "Share trip data with travel partners. Split expenses instantly with UPI.",
  },
  {
    icon: ShieldCheck,
    title: "Privacy First",
    description: "GPS only active during Trip Mode. Zero third-party data sharing. Your data, your rules.",
  },
];

const BenefitsSection = () => {
  return (
    <section className="section-padding">
      <div className="container mx-auto">
        <motion.div {...fadeInUp} className="text-center mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
            Why GoTracker
          </span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
            Travel with confidence
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              {...fadeInUp}
              transition={{ ...fadeInUp.transition, delay: index * 0.08 }}
              className="flex gap-5 p-6 rounded-3xl bg-muted/50 hover:bg-muted transition-colors"
            >
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <benefit.icon className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-foreground mb-1">
                  {benefit.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
