import { motion } from "framer-motion";
import { MapPin, ArrowRight, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeInUp = {
  initial: { opacity: 0, y: 12 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5, ease: "easeOut" as const },
};

const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center section-padding pt-32 overflow-hidden">
      {/* Grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.02)_1px,transparent_1px)] bg-[size:64px_64px]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div {...fadeInUp} className="mb-6">
            <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse-dot" />
              GPS Tracking Active
            </span>
          </motion.div>

          <motion.h1
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6 leading-[1.1]"
          >
            Your journey,{" "}
            <span className="text-gradient">precisely documented.</span>
          </motion.h1>

          <motion.p
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto"
          >
            Automatic GPS tracking, secure expense management, and instant UPI
            settlements. All in one encrypted vault.
          </motion.p>

          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button size="lg" className="gap-2 px-8 h-12 text-base">
              Start Tracking <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="lg" className="gap-2 px-8 h-12 text-base">
              <Shield className="w-4 h-4" /> View Security Protocol
            </Button>
          </motion.div>

          {/* Live coordinate display */}
          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.4 }}
            className="mt-16 inline-flex items-center gap-6 px-6 py-3 rounded-2xl shadow-card bg-card"
          >
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Location</span>
            </div>
            <div className="h-4 w-px bg-border" />
            <span className="font-mono text-sm tabular-nums text-foreground">
              28.6139°N, 77.2090°E
            </span>
            <div className="h-4 w-px bg-border" />
            <span className="text-xs font-mono text-accent uppercase tracking-widest">● Live</span>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
